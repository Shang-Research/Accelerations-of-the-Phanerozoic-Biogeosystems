#!/usr/bin/env python3
#
# This python script plots the power laws and exponentially truncated power laws for the negative, positive, and all accelerations of genus richness, origination, extinction, atmospheric CO2 level, and global average temperature.

# Tested using Python 3.9, Windows 10, version 22H2
#
# Haitao Shang
# Copyright 2024
#
# LICENSE AGREEMENT
# - - - - - - - - -
# All rights reserved.
# Use and redistributions of this code is permitted for commercial and non-commercial purposes,
# under the following conditions:

#	* Redistributions must retain the above copyright notice, this list of
#	  conditions and the following disclaimer in the code itself, as well
#	  as in documentation and/or other materials provided with the code.
#	* Neither the name of the original author (Haitao Shang), nor the names
#	  of its contributors may be used to endorse or promote products derived
#	  from this code without specific prior written permission.
#	* Proper attribution must be given to the original author, including a
#     reference to any peer-reviewed publication through which the code was published.
#
# THIS CODE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS "AS IS" AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS CODE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# - - - - - - - - -


from scipy.optimize import curve_fit
import pandas as pd
import numpy as np
from sklearn.metrics import r2_score
from scipy import stats
import matplotlib as mpl
import matplotlib.pyplot as plt
import powerlaw
import string

def objective(x, a, b):
    return a*x+b

def fitting(x, y):
    popt, _ = curve_fit(objective, x, y)
    a, b = popt
    return a, b

def truncated_power_law(x, a, b):
    return ((x ** (-a)) * np.exp(-x*b))

##########################################################################################################
##########################################################################################################
#                                   Accelerations of genus richness                                      #
##########################################################################################################
##########################################################################################################
genus_accelerations_dataframe = pd.read_csv("Datasets/Time Series for the Acceleration of Genus Richness.csv", encoding='unicode_escape')
genus_acceleration = np.array(genus_accelerations_dataframe["Acceleration of Genus Richness (genus/Myr^2)"])

num_bins = 10
##########################################################################################################
#                                         Negative accelerations                                         #
##########################################################################################################
decrease_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i < 0])
decrease_counts, bin_edges = np.histogram(decrease_in_genus_acceleration, bins=num_bins)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept

r2_score(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(decrease_counts)[:]-decrease_predicted_log10_counts[:])**2))
stats.kstest(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])

##########################################################################################################
#                                         Positive accelerations                                         #
##########################################################################################################
increase_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i > 0])
increase_counts, bin_edges = np.histogram(increase_in_genus_acceleration, bins=num_bins)
increase_middle_points = (np.abs(bin_edges)[1:num_bins+1] + np.abs(bin_edges)[0:num_bins]) / 2
slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept

r2_score(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(increase_counts)[:]-increase_predicted_log10_counts[:])**2))
stats.kstest(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(increase_counts)[:], increase_predicted_log10_counts)

##########################################################################################################
#                                           All accelerations                                            #
##########################################################################################################
change_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i != 0])
change_counts, bin_edges = np.histogram(change_in_genus_acceleration, bins=num_bins)
change_middle_points = (np.abs(bin_edges)[1:num_bins+1] + np.abs(bin_edges)[0:num_bins]) / 2
slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept

r2_score(np.log10(change_counts)[:], change_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(change_counts)[:]-change_predicted_log10_counts[:])**2))
stats.kstest(np.log10(change_counts)[:], change_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(change_counts)[:], change_predicted_log10_counts[:])

##########################################################################################################
#                             Power laws and exponentially truncated power laws                          #
##########################################################################################################
fig, axes = plt.subplots(5, 3, figsize=(15, 35))
fig.tight_layout(h_pad=15, w_pad=5)

mpl.rcParams['axes.linewidth'] = 2
a, b = 0.9, 0.91

plt.subplot(5, 3, 1)
decrease_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i < 0])
hist_values, bin_edges = np.histogram(decrease_in_genus_acceleration, bins=num_bins, density=True)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
normalized_hist_values = hist_values/np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(decrease_in_genus_acceleration)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
decrease_predicted_hist_values = truncated_power_law(decrease_middle_points, para_mu, para_lambda)
normalized_decrease_predicted_hist_values = decrease_predicted_hist_values/np.sum(decrease_predicted_hist_values)*len(decrease_in_genus_acceleration)

plt.scatter(np.log10(decrease_middle_points), np.log10(normalized_hist_values*len(decrease_in_genus_acceleration)), marker="o", facecolor="red", edgecolor="red", linewidth=2, s=200)
plt.plot(np.log10(decrease_middle_points), np.log10(normalized_decrease_predicted_hist_values), "--", color="black", linewidth=5, label="ETPL")

slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept
plt.plot(np.log10(decrease_middle_points)[:], decrease_predicted_log10_counts[:], "--", color="grey", linewidth=5, label="PL")
plt.xticks(np.arange(0.4, 1.91, step=0.3))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xlim(0.4, 1.98)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{NA}_{\mathrm{GR}}| \right)$", fontsize=22)
plt.ylabel(r"$\log_{10}$(Count)", fontsize=22)
plt.title("Negative acceleration of GR", fontsize=22)
lgnd=plt.legend(fontsize=25, markerscale=0.1, loc='lower left')
axes[0, 0].text(a, b, string.ascii_lowercase[0], transform=axes[0, 0].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 2)
increase_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i > 0])
hist_values, bin_edges = np.histogram(increase_in_genus_acceleration, bins=num_bins, density=True)
increase_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(increase_in_genus_acceleration)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
increase_predicted_hist_values = truncated_power_law(increase_middle_points, para_mu, para_lambda)
normalized_increase_predicted_hist_values = increase_predicted_hist_values / np.sum(increase_predicted_hist_values)*len(increase_in_genus_acceleration)

plt.scatter(np.log10(increase_middle_points), np.log10(normalized_hist_values*len(increase_in_genus_acceleration)), marker="o", facecolor="red", edgecolor="red", linewidth=2, s=200)
plt.plot(np.log10(increase_middle_points), np.log10(normalized_increase_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept
plt.plot(np.log10(increase_middle_points)[:], increase_predicted_log10_counts[:], "--", color="grey", linewidth=5)
plt.xticks(np.arange(0.7, 2.21, step=0.3))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xlim(0.7, 2.28)
plt.ylim(0, 3.5)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{PA}_{\mathrm{GR}}| \right)$", fontsize=22)
plt.title("Positive acceleration of GR", fontsize=22)
axes[0, 1].text(a, b, string.ascii_lowercase[1], transform=axes[0, 1].transAxes, size=28, weight='bold')


plt.subplot(5, 3, 3)
change_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i != 0])
hist_values, bin_edges = np.histogram(change_in_genus_acceleration, bins=num_bins, density=True)
change_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(change_in_genus_acceleration)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
change_predicted_hist_values = truncated_power_law(change_middle_points, para_mu, para_lambda)
normalized_change_predicted_hist_values = change_predicted_hist_values / np.sum(change_predicted_hist_values)*len(change_in_genus_acceleration)

plt.scatter(np.log10(change_middle_points), np.log10(normalized_hist_values*len(change_in_genus_acceleration)), marker="o", facecolor="red", edgecolor="red", linewidth=2, s=200)
plt.plot(np.log10(change_middle_points), np.log10(normalized_change_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept
plt.plot(np.log10(change_middle_points)[:], change_predicted_log10_counts[:], "--", color="grey", linewidth=5)
plt.xticks(np.arange(0.7, 2.21, step=0.3))
plt.yticks(np.arange(0, 4.01, step=0.5))
plt.xlim(0.7, 2.28)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{AA}_{\mathrm{GR}}| \right)$", fontsize=22)
plt.title("All acceleration of GR", fontsize=22)
axes[0, 2].text(a, b, string.ascii_lowercase[2], transform=axes[0, 2].transAxes, size=28, weight='bold')


##########################################################################################################
##########################################################################################################
#                                                 Origination                                            #
##########################################################################################################
##########################################################################################################
origination_accelerations_dataframe = pd.read_csv("Datasets/Time Series for the Acceleration of Origination.csv", encoding='unicode_escape')
origination_accelerations = np.array(origination_accelerations_dataframe["Acceleration of Origination (1/Myr^2)"])

num_bins = 10
##########################################################################################################
#                                         Negative accelerations                                         #
##########################################################################################################
decrease_in_origination_accelerations = np.array([np.abs(i) for i in origination_accelerations if i < 0])
decrease_counts, bin_edges = np.histogram(decrease_in_origination_accelerations, bins=num_bins)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept

r2_score(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(decrease_counts)[:]-decrease_predicted_log10_counts[:])**2))
stats.kstest(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])

##########################################################################################################
#                                         Positive accelerations                                         #
##########################################################################################################
increase_in_origination_accelerations = np.array([np.abs(i) for i in origination_accelerations if i > 0])
increase_counts, bin_edges = np.histogram(increase_in_origination_accelerations, bins=num_bins)
increase_middle_points = (np.abs(bin_edges)[1:num_bins+1] + np.abs(bin_edges)[0:num_bins]) / 2
slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept

r2_score(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(increase_counts)[:]-increase_predicted_log10_counts[:])**2))
stats.kstest(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(increase_counts)[:], increase_predicted_log10_counts)

##########################################################################################################
#                                           All accelerations                                            #
##########################################################################################################
change_in_origination_accelerations = np.array([np.abs(i) for i in origination_accelerations if i != 0])
change_counts, bin_edges = np.histogram(change_in_origination_accelerations, bins=num_bins)
change_middle_points = (np.abs(bin_edges)[1:num_bins+1] + np.abs(bin_edges)[0:num_bins]) / 2
slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept

r2_score(np.log10(change_counts)[:], change_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(change_counts)[:]-change_predicted_log10_counts[:])**2))
stats.kstest(np.log10(change_counts)[:], change_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(change_counts)[:], change_predicted_log10_counts[:])

##########################################################################################################
#                             Power laws and exponentially truncated power laws                          #
##########################################################################################################
plt.subplot(5, 3, 4)
decrease_in_origination_accelerations = np.array([np.abs(i) for i in origination_accelerations if i < 0])
hist_values, bin_edges = np.histogram(decrease_in_origination_accelerations, bins=num_bins, density=True)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
normalized_hist_values = hist_values/np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(decrease_in_origination_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
decrease_predicted_hist_values = truncated_power_law(decrease_middle_points, para_mu, para_lambda)
normalized_decrease_predicted_hist_values = decrease_predicted_hist_values/np.sum(decrease_predicted_hist_values)*len(decrease_in_origination_accelerations)

plt.scatter(np.log10(decrease_middle_points), np.log10(normalized_hist_values*len(decrease_in_origination_accelerations)), marker="o", facecolor="blue", edgecolor="blue", linewidth=2, s=200)
plt.plot(np.log10(decrease_middle_points), np.log10(normalized_decrease_predicted_hist_values), "--", color="black", linewidth=5, label="ETPL")

slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept
plt.plot(np.log10(decrease_middle_points)[:], decrease_predicted_log10_counts[:], "--", color="grey", linewidth=5, label="PL")

plt.xticks(np.arange(-2.1, -0.59, step=0.5))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xlim(-2.2, -0.5)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{NA}_{\mathrm{OR}}| \right)$", fontsize=22)
plt.ylabel(r"$\log_{10}$(Count)", fontsize=22)
plt.title("Negative acceleration of OR", fontsize=22)
axes[1, 0].text(a, b, string.ascii_lowercase[3], transform=axes[1, 0].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 5)
increase_in_origination_accelerations = np.array([np.abs(i) for i in origination_accelerations if i > 0])
hist_values, bin_edges = np.histogram(increase_in_origination_accelerations, bins=num_bins, density=True)
increase_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(increase_in_origination_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
increase_predicted_hist_values = truncated_power_law(increase_middle_points, para_mu, para_lambda)
normalized_increase_predicted_hist_values = increase_predicted_hist_values / np.sum(increase_predicted_hist_values)*len(increase_in_origination_accelerations)

plt.scatter(np.log10(increase_middle_points), np.log10(normalized_hist_values*len(increase_in_origination_accelerations)), marker="o", facecolor="blue", edgecolor="blue", linewidth=2, s=200)
plt.plot(np.log10(increase_middle_points), np.log10(normalized_increase_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept
plt.plot(np.log10(increase_middle_points)[:], increase_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(-2.1, -0.59, step=0.5))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xlim(-2.2, -0.5)
plt.ylim(0, 3.5)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{PA}_{\mathrm{OR}}| \right)$", fontsize=22)
plt.title("Positive acceleration of OR", fontsize=22)
axes[1, 1].text(a, b, string.ascii_lowercase[4], transform=axes[1, 1].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 6)
change_in_origination_accelerations = np.array([np.abs(i) for i in origination_accelerations if i != 0])
hist_values, bin_edges = np.histogram(change_in_origination_accelerations, bins=num_bins, density=True)
change_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(change_in_origination_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
change_predicted_hist_values = truncated_power_law(change_middle_points, para_mu, para_lambda)
normalized_change_predicted_hist_values = change_predicted_hist_values / np.sum(change_predicted_hist_values)*len(change_in_origination_accelerations)

plt.scatter(np.log10(change_middle_points), np.log10(normalized_hist_values*len(change_in_origination_accelerations)), marker="o", facecolor="blue", edgecolor="blue", linewidth=2, s=200)
plt.plot(np.log10(change_middle_points), np.log10(normalized_change_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept
plt.plot(np.log10(change_middle_points)[:], change_predicted_log10_counts[:], "--", color="grey", linewidth=5)
plt.xticks(np.arange(-2.1, -0.59, step=0.5))
plt.yticks(np.arange(0, 4.01, step=0.5))
plt.xlim(-2.2, -0.5)
plt.ylim(0, 4.0)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{AA}_{\mathrm{OR}}| \right)$", fontsize=22)
plt.title("All acceleration of OR", fontsize=22)
axes[1, 2].text(a, b, string.ascii_lowercase[5], transform=axes[1, 2].transAxes, size=28, weight='bold')


##########################################################################################################
##########################################################################################################
#                                      Accelerations of extinction                                       #
##########################################################################################################
##########################################################################################################
extinction_accelerations_dataframe = pd.read_csv("Datasets/Time Series for the Acceleration of Extinction.csv", encoding='unicode_escape')
extinction_accelerations = np.array(extinction_accelerations_dataframe["Acceleration of Extinction (1/Myr^2)"])

num_bins = 10
##########################################################################################################
#                                         Negative accelerations                                         #
##########################################################################################################
decrease_in_extinction_accelerations = np.array([np.abs(i) for i in extinction_accelerations if i < 0])
hist_values, bin_edges = np.histogram(decrease_in_extinction_accelerations, bins=num_bins, density=True)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
normalized_hist_values = hist_values/np.sum(hist_values)
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept

r2_score(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(decrease_counts)[:]-decrease_predicted_log10_counts[:])**2))
stats.kstest(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(decrease_counts)[:], decrease_predicted_log10_counts[:])

##########################################################################################################
#                                         Positive accelerations                                         #
##########################################################################################################
increase_in_extinction_accelerations = np.array([np.abs(i) for i in extinction_accelerations if i > 0])
hist_values, bin_edges = np.histogram(increase_in_extinction_accelerations, bins=num_bins, density=True)
increase_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
normalized_hist_values = hist_values / np.sum(hist_values)
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept

r2_score(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(increase_counts)[:]-increase_predicted_log10_counts[:])**2))
stats.kstest(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(increase_counts)[:], increase_predicted_log10_counts)

##########################################################################################################
#                                           All accelerations                                            #
##########################################################################################################
change_in_extinction_accelerations = np.array([np.abs(i) for i in extinction_accelerations if i != 0])
hist_values, bin_edges = np.histogram(change_in_extinction_accelerations, bins=num_bins, density=True)
change_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)
slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept

r2_score(np.log10(change_counts)[:], change_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(change_counts)[:]-change_predicted_log10_counts[:])**2))
stats.kstest(np.log10(change_counts)[:], change_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(change_counts)[:], change_predicted_log10_counts[:])

##########################################################################################################
#                             Power laws and exponentially truncated power laws                          #
##########################################################################################################
num_bins = 10
plt.subplot(5, 3, 7)
powerlaw_fit = powerlaw.Fit(decrease_in_extinction_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
decrease_predicted_hist_values = truncated_power_law(decrease_middle_points, para_mu, para_lambda)
normalized_decrease_predicted_hist_values = decrease_predicted_hist_values/np.sum(decrease_predicted_hist_values)*len(decrease_in_extinction_accelerations)

plt.scatter(np.log10(decrease_middle_points), np.log10(normalized_hist_values*len(decrease_in_extinction_accelerations)), marker="o", facecolor="orange", edgecolor="orange", linewidth=2, s=200)
plt.plot(np.log10(decrease_middle_points), np.log10(normalized_decrease_predicted_hist_values), "--", color="black", linewidth=5, label="ETPL")

slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept
plt.plot(np.log10(decrease_middle_points)[:], decrease_predicted_log10_counts[:], "--", color="grey", linewidth=5, label="PL")

plt.xticks(np.arange(-1.8, -0.29, step=0.5))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xlim(-1.8, -0.17)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{NA}_{\mathrm{EX}}| \right)$", fontsize=22)
plt.ylabel(r"$\log_{10}$(Count)", fontsize=22)
plt.title("Negative acceleration of EX", fontsize=22)
axes[2, 0].text(a, b, string.ascii_lowercase[6], transform=axes[2, 0].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 8)
powerlaw_fit = powerlaw.Fit(increase_in_extinction_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
increase_predicted_hist_values = truncated_power_law(increase_middle_points, para_mu, para_lambda)
normalized_increase_predicted_hist_values = increase_predicted_hist_values / np.sum(increase_predicted_hist_values)*len(increase_in_extinction_accelerations)

plt.scatter(np.log10(increase_middle_points), np.log10(normalized_hist_values*len(increase_in_extinction_accelerations)), marker="o", facecolor="orange", edgecolor="orange", linewidth=2, s=200)
plt.plot(np.log10(increase_middle_points), np.log10(normalized_increase_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept
plt.plot(np.log10(increase_middle_points)[:], increase_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(-2, -0.49, step=0.5))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xlim(-2, -0.38)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{PA}_{\mathrm{EX}}| \right)$", fontsize=22)
plt.title("Positive acceleration of EX", fontsize=22)
axes[2, 1].text(a, b, string.ascii_lowercase[7], transform=axes[2, 1].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 9)
powerlaw_fit = powerlaw.Fit(change_in_extinction_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
change_predicted_hist_values = truncated_power_law(change_middle_points, para_mu, para_lambda)
normalized_change_predicted_hist_values = change_predicted_hist_values / np.sum(change_predicted_hist_values)*len(change_in_extinction_accelerations)

plt.scatter(np.log10(change_middle_points), np.log10(normalized_hist_values*len(change_in_extinction_accelerations)), marker="o", facecolor="orange", edgecolor="orange", linewidth=2, s=200)
plt.plot(np.log10(change_middle_points), np.log10(normalized_change_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept
plt.plot(np.log10(change_middle_points)[:], change_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(-1.8, -0.29, step=0.5))
plt.yticks(np.arange(0, 4.01, step=0.5))
plt.xlim(-1.8, -0.17)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{AA}_{\mathrm{EX}}| \right)$", fontsize=22)
plt.title("All acceleration of EX", fontsize=22)
axes[2, 2].text(a, b, string.ascii_lowercase[8], transform=axes[2, 2].transAxes, size=28, weight='bold')


##########################################################################################################
##########################################################################################################
#                              Accelerations of the atmospheric CO2 level                                #
##########################################################################################################
##########################################################################################################
CO2_accelerations_dataframe = pd.read_csv("Datasets/Time Series for the Acceleration of CO2.csv", encoding='unicode_escape')
CO2_accelerations = np.array(CO2_accelerations_dataframe["Acceleration of CO2 (ppm/Myr^2)"])

num_bins = 10
##########################################################################################################
#                                         Negative accelerations                                         #
##########################################################################################################
decrease_in_CO2_accelerations = np.array([np.abs(i) for i in CO2_accelerations if i < 0])
decrease_counts, bin_edges = np.histogram(decrease_in_CO2_accelerations, bins=num_bins)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
slope, intercept = fitting(np.log10(decrease_middle_points), np.log10(decrease_counts))
predicted_log10_counts = slope*np.log10(decrease_middle_points) + intercept

r2_score(np.log10(decrease_counts)[:], predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(decrease_counts)[:]-predicted_log10_counts[:])**2))
stats.kstest(np.log10(decrease_counts)[:], predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(decrease_counts)[:], predicted_log10_counts[:])

##########################################################################################################
#                                         Positive accelerations                                         #
##########################################################################################################
increase_in_CO2_accelerations = np.array([np.abs(i) for i in CO2_accelerations if i > 0])
increase_counts = np.array([1969,  113,   23,    7,    5,    4,    2,     1,    1])
increase_middle_points = np.array([ 188.04819183,  564.10791653,  940.16764122, 1316.22736591,
                           1692.2870906 , 2068.3468153 , 2444.40653999,
                           3196.52598937, 3572.58571407])
slope, intercept = fitting(np.log10(increase_middle_points), np.log10(increase_counts))
increase_predicted_log10_counts = slope*np.log10(increase_middle_points) + intercept

r2_score(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(increase_counts)[:]-increase_predicted_log10_counts[:])**2))
stats.kstest(np.log10(increase_counts)[:], increase_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(increase_counts)[:], increase_predicted_log10_counts)

##########################################################################################################
#                                           All accelerations                                            #
##########################################################################################################
change_in_CO2_accelerations = np.array([np.abs(i) for i in CO2_accelerations if i != 0])
change_counts, bin_edges = np.histogram(change_in_CO2_accelerations, bins=num_bins)
change_middle_points = (np.abs(bin_edges)[1:num_bins+1]+np.abs(bin_edges)[0:num_bins])/2
slope, intercept = fitting(np.log10(change_middle_points), np.log10(change_counts))
change_predicted_log10_counts = slope*np.log10(change_middle_points) + intercept

r2_score(np.log10(change_counts)[:], change_predicted_log10_counts[:])
np.sqrt(np.mean((np.log10(change_counts)[:]-change_predicted_log10_counts[:])**2))
stats.kstest(np.log10(change_counts)[:], change_predicted_log10_counts[:])
stats.cramervonmises_2samp(np.log10(change_counts)[:], change_predicted_log10_counts[:])

##########################################################################################################
#                             Power laws and exponentially truncated power laws                          #
##########################################################################################################
plt.subplot(5, 3, 10)
powerlaw_fit = powerlaw.Fit(decrease_in_CO2_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
decrease_predicted_hist_values = truncated_power_law(decrease_middle_points, para_mu, para_lambda)
normalized_decrease_predicted_hist_values = decrease_predicted_hist_values/np.sum(decrease_predicted_hist_values)*len(decrease_in_CO2_accelerations)

plt.scatter(np.log10(decrease_middle_points), np.log10(decrease_counts), marker="o", facecolor="green", edgecolor="green", linewidth=2, s=200)
plt.plot(np.log10(decrease_middle_points), np.log10(normalized_decrease_predicted_hist_values), "--", color="black", linewidth=5, label="ETPL")

slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept
plt.plot(np.log10(decrease_middle_points)[:], decrease_predicted_log10_counts[:], "--", color="grey", linewidth=5, label="PL")
plt.xticks(np.arange(2.2, 3.71, step=0.5))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{NA}_{\mathrm{CO_2}}| \right)$", fontsize=22)
plt.ylabel(r"$\log_{10}$(Count)", fontsize=22)
plt.title("Negative acceleration of $\mathrm{CO_2}$", fontsize=22)
axes[3, 0].text(a, b, string.ascii_lowercase[9], transform=axes[3, 0].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 11)
powerlaw_fit = powerlaw.Fit(increase_in_CO2_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
increase_predicted_hist_values = truncated_power_law(increase_middle_points, para_mu, para_lambda)
normalized_increase_predicted_hist_values = increase_predicted_hist_values / np.sum(increase_predicted_hist_values)*len(increase_in_CO2_accelerations)

plt.scatter(np.log10(increase_middle_points), np.log10(increase_counts), marker="o", facecolor="green", edgecolor="green", linewidth=2, s=200)
plt.plot(np.log10(increase_middle_points), np.log10(normalized_increase_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept
plt.plot(np.log10(increase_middle_points)[:], increase_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(2.2, 3.71, step=0.5))
plt.yticks(np.arange(0, 3.51, step=0.5))
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{PA}_{\mathrm{CO_2}}| \right)$", fontsize=22)
plt.title("Positive acceleration of $\mathrm{CO_2}$", fontsize=22)
axes[3, 1].text(a, b, string.ascii_lowercase[10], transform=axes[3, 1].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 12)
powerlaw_fit = powerlaw.Fit(change_in_CO2_accelerations)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
change_predicted_hist_values = truncated_power_law(change_middle_points, para_mu, para_lambda)
normalized_change_predicted_hist_values = change_predicted_hist_values / np.sum(change_predicted_hist_values)*len(change_in_CO2_accelerations)

plt.scatter(np.log10(change_middle_points), np.log10(change_counts), marker="o", facecolor="green", edgecolor="green", linewidth=2, s=200)
plt.plot(np.log10(change_middle_points), np.log10(normalized_change_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept
plt.plot(np.log10(change_middle_points)[:], change_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(2.2, 3.71, step=0.5))
plt.yticks(np.arange(0, 4.01, step=0.5))
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{AA}_{\mathrm{CO_2}}| \right)$", fontsize=22)
plt.title("All acceleration of $\mathrm{CO_2}$", fontsize=22)
axes[3, 2].text(a, b, string.ascii_lowercase[11], transform=axes[3, 2].transAxes, size=28, weight='bold')


##########################################################################################################
##########################################################################################################
#                          Accelerations of the global average temperature                               #
##########################################################################################################
##########################################################################################################
temperature_accelerations_dataframe = pd.read_csv("Datasets/Time Series for the Acceleration of temperature.csv", encoding='unicode_escape')
temperature_accelerations = np.array(temperature_accelerations_dataframe["Acceleration of temperature (C/Myr^2)"])

##########################################################################################################
#                                         Negative accelerations                                         #
##########################################################################################################
decrease_in_temperature = np.array([np.abs(i) for i in temperature_accelerations if i < 0])
decrease_counts, bin_edges = np.histogram(decrease_in_temperature, bins=10)
decrease_middle_points = (np.abs(bin_edges)[1:11]+np.abs(bin_edges)[0:10])/2
slope, intercept = fitting(np.log10(decrease_middle_points), np.log10(decrease_counts))
predicted_log10_counts = slope*np.log10(decrease_middle_points) + intercept

##########################################################################################################
#                                         Positive accelerations                                         #
##########################################################################################################
increase_in_temperature = np.array([np.abs(i) for i in temperature_accelerations if i > 0])
increase_counts, bin_edges = np.histogram(increase_in_temperature, bins=10)
increase_middle_points = (np.abs(bin_edges)[1:11]+np.abs(bin_edges)[0:10])/2
slope, intercept = fitting(np.log10(increase_middle_points), np.log10(increase_counts))
predicted_log10_counts = slope*np.log10(increase_middle_points) + intercept

##########################################################################################################
#                                           All accelerations                                            #
##########################################################################################################
change_in_temperature = np.array([np.abs(i) for i in temperature_accelerations if i != 0])
change_counts, bin_edges = np.histogram(change_in_temperature, bins=10)
change_middle_points = (np.abs(bin_edges)[1:11]+np.abs(bin_edges)[0:10])/2
slope, intercept = fitting(np.log10(change_middle_points), np.log10(change_counts))
predicted_log10_counts = slope*np.log10(change_middle_points) + intercept

##########################################################################################################
#                             Power laws and exponentially truncated power laws                          #
##########################################################################################################
num_bins = 10

plt.subplot(5, 3, 13)
decrease_in_temperature = np.array([np.abs(i) for i in temperature_accelerations if i < 0])
hist_values, bin_edges = np.histogram(decrease_in_temperature, bins=num_bins, density=True)
decrease_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(decrease_in_temperature)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
decrease_predicted_hist_values = truncated_power_law(decrease_middle_points, para_mu, para_lambda)
normalized_decrease_predicted_hist_values = decrease_predicted_hist_values / np.sum(decrease_predicted_hist_values)*len(decrease_in_temperature)

plt.scatter(np.log10(decrease_middle_points), np.log10(normalized_hist_values*len(decrease_in_temperature)), marker="o", facecolor="purple", edgecolor="purple", linewidth=2, s=200)
plt.plot(np.log10(decrease_middle_points), np.log10(normalized_decrease_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(decrease_middle_points)[:], np.log10(decrease_counts)[:])
decrease_predicted_log10_counts = slope * np.log10(decrease_middle_points) + intercept
plt.plot(np.log10(decrease_middle_points)[:], decrease_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(0, 1.51, step=0.5))
plt.xlim(0, 1.57)
plt.yticks(np.arange(0, 3.55, step=0.5))
plt.ylim(-0.1, 3.55)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{NA}_{\mathrm{T}}| \right)$", fontsize=22)
plt.ylabel(r"$\log_{10}$(Count)", fontsize=22)
plt.title("Negative acceleration of $\mathrm{T}$", fontsize=22)
axes[4, 0].text(a, b, string.ascii_lowercase[12], transform=axes[4, 0].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 14)
increase_in_temperature_acceleration = np.array([np.abs(i) for i in temperature_accelerations if i > 0])
hist_values, bin_edges = np.histogram(increase_in_temperature_acceleration, bins=num_bins, density=True)
increase_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(increase_in_temperature_acceleration)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
increase_predicted_hist_values = truncated_power_law(increase_middle_points, para_mu, para_lambda)
normalized_increase_predicted_hist_values = increase_predicted_hist_values / np.sum(increase_predicted_hist_values)*len(increase_in_temperature_acceleration)

plt.scatter(np.log10(increase_middle_points), np.log10(normalized_hist_values*len(increase_in_temperature_acceleration)), marker="o", facecolor="purple", edgecolor="purple", linewidth=2, s=200)
plt.plot(np.log10(increase_middle_points), np.log10(normalized_increase_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(increase_middle_points)[:], np.log10(increase_counts)[:])
increase_predicted_log10_counts = slope * np.log10(increase_middle_points) + intercept
plt.plot(np.log10(increase_middle_points)[:], increase_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(0, 1.51, step=0.5))
plt.xlim(0, 1.57)
plt.yticks(np.arange(0, 3.55, step=0.5))
plt.ylim(-0.1, 3.55)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{PA}_{\mathrm{T}}| \right)$", fontsize=22)
plt.title("Positive acceleration of $\mathrm{T}$", fontsize=22)
axes[4, 1].text(a, b, string.ascii_lowercase[13], transform=axes[4, 1].transAxes, size=28, weight='bold')

plt.subplot(5, 3, 15)
change_in_temperature_acceleration = np.array([np.abs(i) for i in temperature_accelerations if i != 0])
hist_values, bin_edges = np.histogram(change_in_temperature_acceleration, bins=num_bins, density=True)
change_middle_points = (np.abs(bin_edges)[1:num_bins + 1] + np.abs(bin_edges)[0:num_bins]) / 2
normalized_hist_values = hist_values / np.sum(hist_values)

powerlaw_fit = powerlaw.Fit(change_in_temperature_acceleration)
para_mu, para_lambda = powerlaw_fit.truncated_power_law.parameter1, powerlaw_fit.truncated_power_law.parameter2
change_predicted_hist_values = truncated_power_law(change_middle_points, para_mu, para_lambda)
normalized_change_predicted_hist_values = change_predicted_hist_values / np.sum(change_predicted_hist_values)*len(change_in_temperature_acceleration)

plt.scatter(np.log10(change_middle_points), np.log10(normalized_hist_values*len(change_in_temperature_acceleration)), marker="o", facecolor="purple", edgecolor="purple", linewidth=2, s=200)
plt.plot(np.log10(change_middle_points), np.log10(normalized_change_predicted_hist_values), "--", color="black", linewidth=5)

slope, intercept = fitting(np.log10(change_middle_points)[:], np.log10(change_counts)[:])
change_predicted_log10_counts = slope * np.log10(change_middle_points) + intercept
plt.plot(np.log10(change_middle_points)[:], change_predicted_log10_counts[:], "--", color="grey", linewidth=5)

plt.xticks(np.arange(0, 1.51, step=0.5))
plt.xlim(0, 1.57)
plt.yticks(np.arange(0, 4.05, step=0.5))
plt.ylim(-0.1, 4.05)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.xlabel(r"$\log_{10} \left(|\mathrm{AA}_{\mathrm{T}}| \right)$", fontsize=22)
plt.title("All acceleration of $\mathrm{T}$", fontsize=22)
axes[4, 2].text(a, b, string.ascii_lowercase[14], transform=axes[4, 2].transAxes, size=28, weight='bold')

plt.savefig('Power Laws and Exponentially Truncated Power Laws of All Quantities.pdf', bbox_inches="tight", dpi=100)