#!/usr/bin/env python3
#
# This python script performs the likelihood-ratio test (LRT) and Bayesian information criterion (BIC) to select the best-fitting distribution for the negative, positive, and all accelerations of genus richness.
# The candidate distributions include the power law, exponentially truncated power law, lognormal, exponential, and stretched-exponential distributions.

# Tested using Python 3.9, Windows 10, version 22H2
#
# Haitao Shang
# Copyright 2024
#
# LICENSE AGREEMENT
# - - - - - - - - -
# All rights reserved.
# Use and redistributions of this code is permitted for commercial and non-commercial purposes,
# under the following conditions:

#	* Redistributions must retain the above copyright notice, this list of
#	  conditions and the following disclaimer in the code itself, as well
#	  as in documentation and/or other materials provided with the code.
#	* Neither the name of the original author (Haitao Shang), nor the names
#	  of its contributors may be used to endorse or promote products derived
#	  from this code without specific prior written permission.
#	* Proper attribution must be given to the original author, including a
#     reference to any peer-reviewed publication through which the code was published.
#
# THIS CODE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS "AS IS" AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS CODE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# - - - - - - - - -

import pandas as pd
import numpy as np
import powerlaw

##########################################################################################################
#                               Dataset on the accelerations of genus richness                           #
##########################################################################################################
genus_accelerations_dataframe = pd.read_csv("Datasets/Time Series for the Acceleration of Genus Richness.csv", encoding='unicode_escape')
genus_acceleration = np.array(genus_accelerations_dataframe["Acceleration of Genus Richness (genus/Myr^2)"])

##########################################################################################################
#                                    Negative accelerations of genus richness                            #
##########################################################################################################
decrease_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i < 0])
powerlaw_fit = powerlaw.Fit(decrease_in_genus_acceleration)
powerlaw_fit.distribution_compare('truncated_power_law', 'power_law')
powerlaw_fit.distribution_compare('truncated_power_law', 'lognormal')
powerlaw_fit.distribution_compare('truncated_power_law', 'exponential')
powerlaw_fit.distribution_compare('truncated_power_law', 'stretched_exponential')

BIC_truncated_power_law_decrease = 2 * np.log(len(decrease_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.truncated_power_law.loglikelihoods(decrease_in_genus_acceleration))
BIC_power_law_decrease = 1 * np.log(len(decrease_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.power_law.loglikelihoods(decrease_in_genus_acceleration))
BIC_lognormal_decrease = 2 * np.log(len(decrease_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.lognormal.loglikelihoods(decrease_in_genus_acceleration))
BIC_exponential_decrease = 1 * np.log(len(decrease_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.exponential.loglikelihoods(decrease_in_genus_acceleration))
BIC_stretched_exponential_decrease = 2 * np.log(len(decrease_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.stretched_exponential.loglikelihoods(decrease_in_genus_acceleration))

##########################################################################################################
#                                  Positive accelerations of genus richness                              #
##########################################################################################################
increase_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i > 0])
powerlaw_fit = powerlaw.Fit(increase_in_genus_acceleration)
powerlaw_fit.distribution_compare('truncated_power_law', 'power_law')
powerlaw_fit.distribution_compare('truncated_power_law', 'lognormal')
powerlaw_fit.distribution_compare('truncated_power_law', 'exponential')
powerlaw_fit.distribution_compare('truncated_power_law', 'stretched_exponential')

BIC_truncated_power_law_increase = 2 * np.log(len(increase_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.truncated_power_law.loglikelihoods(increase_in_genus_acceleration))
BIC_power_law_increase = 1 * np.log(len(increase_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.power_law.loglikelihoods(increase_in_genus_acceleration))
BIC_lognormal_increase = 2 * np.log(len(increase_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.lognormal.loglikelihoods(increase_in_genus_acceleration))
BIC_exponential_increase = 1 * np.log(len(increase_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.exponential.loglikelihoods(increase_in_genus_acceleration))
BIC_stretched_exponential_increase = 2 * np.log(len(increase_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.stretched_exponential.loglikelihoods(increase_in_genus_acceleration))

##########################################################################################################
#                                      All accelerations of genus richness                               #
##########################################################################################################
change_in_genus_acceleration = np.array([np.abs(i) for i in genus_acceleration if i != 0])
powerlaw_fit = powerlaw.Fit(change_in_genus_acceleration)
powerlaw_fit.distribution_compare('truncated_power_law', 'power_law')
powerlaw_fit.distribution_compare('truncated_power_law', 'lognormal')
powerlaw_fit.distribution_compare('truncated_power_law', 'exponential')
powerlaw_fit.distribution_compare('truncated_power_law', 'stretched_exponential')

BIC_truncated_power_law_change = 2 * np.log(len(change_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.truncated_power_law.loglikelihoods(change_in_genus_acceleration))
BIC_power_law_change = 1 * np.log(len(change_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.power_law.loglikelihoods(change_in_genus_acceleration))
BIC_lognormal_change = 2 * np.log(len(change_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.lognormal.loglikelihoods(change_in_genus_acceleration))
BIC_exponential_change = 1 * np.log(len(change_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.exponential.loglikelihoods(change_in_genus_acceleration))
BIC_stretched_exponential_change = 2 * np.log(len(change_in_genus_acceleration)) - 2 * np.sum(powerlaw_fit.stretched_exponential.loglikelihoods(change_in_genus_acceleration))